<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <title>CRUD Toko Buah</title>
  <style>
    /* Reset dasar */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    /* Body */
    body {
      font-family: 'Arial', sans-serif;
      line-height: 1.6;
      background-color: #f2f2f2;
    }

    /* Navbar */
    .navbar {
      background-color: #4CAF50;
      padding: 15px 30px; /* Samakan padding */
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: white;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
    }

    .navbar .logo {
      font-size: 2em; /* Samakan ukuran font */
      font-weight: bold;
      letter-spacing: 1.5px;
    }

    .navbar .nav-links {
      display: flex;
      list-style: none;
    }

    .navbar .nav-links li {
      margin-left: 30px; /* Samakan margin */
    }

    .navbar .nav-links a {
      color: white;
      text-decoration: none;
      font-size: 1.1em;
      transition: color 0.3s, transform 0.3s;
    }

    .navbar .nav-links a:hover {
      color: #ffd700;
      transform: scale(1.1);
    }

    /* Container */
    .container {
      padding: 20px;
      border-radius: 10px;
      max-width: 900px;
      margin: 30px auto;
      background-color: #f8f8f8;
      color: #333;
      box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.2);
    }

    h3 {
      font-family: 'Arial', sans-serif;
      color: #333;
      font-size: 26px;
      text-align: center;
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      background-color: #fff;
      border-collapse: collapse;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
      font-size: 18px;
      color: #333;
    }

    th, td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #444;
      color: white;
    }

    tr:nth-child(odd) {
      background-color: #f2f2f2;
    }

    tr:hover {
      background-color: #ddd;
    }

    /* Tombol Tambah Data */
    .add-button {
      text-align: center;
      margin-top: 20px;
    }

    .add-button a {
      padding: 12px 20px;
      background-color: #28a745;
      color: white;
      font-size: 18px;
      text-decoration: none;
      border-radius: 8px;
      transition: background-color 0.3s ease, transform 0.2s ease;
      box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
    }

    .add-button a:hover {
      background-color: #218838;
      transform: translateY(-2px);
    }

    /* Tombol Aksi */
    .action-button {
      background-color: #6c757d;
      color: #fff;
      border: none;
      padding: 8px;
      margin: 5px 0;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
      text-align: center;
      text-decoration: none;
      display: block;
    }

    .action-button:hover {
      background-color: #5a6268;
    }
  </style>
</head>
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar">
    <div class="logo">Dashboard Admin</div>
    <ul class="nav-links">
        <li><a href="dashboard.php">Dashboard Admin</a></li>
        <li><a href="menuadmin.php">Data Buah</a></li>
        <li><a href="riwayat.php">Riwayat Pembelian</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>
<div class="container">
    <br>
    <h3>Data Buah</h3>
<?php
include "koneksi.php"; 

if (isset($_GET['id_buah'])) {
    $id_buah = htmlspecialchars($_GET["id_buah"]);

    $sql = "DELETE FROM buah WHERE id_buah='$id_buah'";
    $hasil = mysqli_query($conn, $sql);

    // Cek jika query DELETE gagal
    if (!$hasil) {
        die("Query gagal: " . mysqli_error($conn));  // Menampilkan pesan error jika query gagal
    } else {
        header("Location: menuadmin.php");
    }
}
?>

<table class="my-3 table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Buah</th>
            <th>Kategori Buah</th>
            <th>Harga</th>
            <th>Gambar</th>
            <th>Aksi</th>
        </tr>
    </thead>

    <?php
    include "koneksi.php";
    $sql = "SELECT * FROM buah ORDER BY id_buah ASC";

    $hasil = mysqli_query($conn, $sql);

    // Cek jika query SELECT gagal
    if (!$hasil) {
        die("Query gagal: " . mysqli_error($conn));  // Menampilkan pesan error jika query gagal
    }

    $no = 0;
    while ($data = mysqli_fetch_array($hasil)) {
        $no++;
    ?>
        <tbody>
            <tr>
                <td><?php echo $no; ?></td>
                <td><?php echo $data["nama_buah"]; ?></td>
                <td><?php echo $data["kategori_buah"]; ?></td>
                <td><?php echo $data["harga"]; ?></td>
                <td>
                    <img src="uploads/<?php echo $data["file_buah"]; ?>" alt="Gambar buah" style="width: 150px; height: auto;">
                </td>
                <td>
                    <a href="update.php?id_buah=<?php echo htmlspecialchars($data['id_buah']); ?>" class="action-button">Update</a>
                    <a href="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>?id_buah=<?php echo $data['id_buah']; ?>" class="action-button">Delete</a>
                </td>
            </tr>
        </tbody>
    <?php
    }
    ?>
</table>
<div class="add-button">
    <a href="tambahbuah.php">Tambah Data</a>
</div>
</div>
</body>
</html>
