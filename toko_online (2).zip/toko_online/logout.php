<?php
session_start();  // Memulai session

// Menghapus semua data sesi
session_unset();
session_destroy();

// Mengarahkan pengguna ke halaman login setelah logout
header("Location: login.html");
exit();
?>
