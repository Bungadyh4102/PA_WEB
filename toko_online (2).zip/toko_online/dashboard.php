<?php
session_start();

// Cek apakah yang login adalah admin
if ($_SESSION['role'] != 'admin') {
    header("Location: login.html");  // Jika bukan admin, arahkan ke login
    exit();
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Toko Buah Online</title>
    <style>
        /* Reset dasar */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body */
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            background-color: #f2f2f2;
        }

        /* Navbar */
        .navbar {
            background-color: #4CAF50;
            padding: 15px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        .navbar .logo {
            font-size: 2em;
            font-weight: bold;
            letter-spacing: 1.5px;
        }

        .navbar .nav-links {
            display: flex;
            list-style: none;
        }

        .navbar .nav-links li {
            margin-left: 30px;
        }

        .navbar .nav-links a {
            color: white;
            text-decoration: none;
            font-size: 1.1em;
            transition: color 0.3s, transform 0.3s;
        }

        .navbar .nav-links a:hover {
            color: #ffd700;
            transform: scale(1.1);
        }

        /* Style Dashboard Content */
        .admin-dashboard {
            padding: 40px;
            text-align: center;
            background-color: #f4f6f9;
            border-radius: 10px;
            margin: 30px auto;
            width: 90%;
            max-width: 800px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.15);
            font-family: Arial, sans-serif;
        }

        .admin-dashboard h1 {
            color: #333;
            font-size: 32px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .admin-dashboard p {
            font-size: 20px;
            color: #555;
        }

        /* Button Style */
        .btn {
            display: inline-block;
            padding: 12px 24px;
            margin-top: 20px;
            background-color: #4CAF50;
            color: #fff;
            font-size: 18px;
            font-family: Arial, sans-serif;
            font-weight: 600;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s, box-shadow 0.3s;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }

        .btn:hover {
            background-color: #388E3C;
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>
<body>
    <!-- Navbar Admin -->
    <nav class="navbar">
        <div class="logo">Dashboard Admin</div>
        <ul class="nav-links">
        <li><a href="dashboard.php">Dashboard Admin</a></li>
        <li><a href="menuadmin.php">Data Buah</a></li>
        <li><a href="riwayat.php">Riwayat Pembayaran</a></li>
        <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <!-- Content -->
    <section class="admin-dashboard">
        <h1>Selamat Datang, Admin!</h1>
        <p>Ini adalah halaman dashboard admin.</p>
    </section>
</body>
</html>
