<?php
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.html");  // Jika belum login, arahkan ke login
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toko Buah Online</title>
    <style>
        /* Reset dasar */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body */
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            background-color: #f2f2f2;
        }

        /* Navbar */
        .navbar {
            background-color: #4CAF50;
            padding: 15px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        .navbar .logo {
            font-size: 2em;
            font-weight: bold;
            letter-spacing: 1.5px;
        }

        .navbar .nav-links {
            display: flex;
            list-style: none;
        }

        .navbar .nav-links li {
            margin-left: 30px;
        }

        .navbar .nav-links a {
            color: white;
            text-decoration: none;
            font-size: 1.1em;
            transition: color 0.3s, transform 0.3s;
        }

        .navbar .nav-links a:hover {
            color: #ffd700;
            transform: scale(1.1);
        }

        .navbar .search-bar input {
            padding: 8px 15px;
            border-radius: 20px;
            border: 1px solid #ddd;
            outline: none;
            transition: border-color 0.3s;
        }

        .navbar .search-bar input:focus {
            border-color: #ffd700;
        }

        .navbar .search-bar input::placeholder {
            color: #888;
            font-size: 0.9em;
        }

        /* Dropdown styling */
        .akun-menu .dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background-color: white;
            min-width: 150px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            border-radius: 4px;
        }

        .akun-menu:hover .dropdown {
            display: block;
        }

        .dropdown li {
            padding: 10px;
        }

        .dropdown li a {
            color: black;
            text-decoration: none;
        }

        .dropdown li a:hover {
            background-color: #f1f1f1;
            border-radius: 4px;
        }

        /* Content */
        .content {
            padding: 20px;
            max-width: 800px;
            margin: 20px auto;
            background-color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            text-align: center;
        }

        .content h2 {
            color: #4CAF50;
            margin-bottom: 10px;
        }

        .content p {
            margin-bottom: 20px;
        }

        .logout-btn {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .logout-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo">Toko Buah Online</div>
        <ul class="nav-links">
            <li><a href="beranda.html">Beranda</a></li>
            <li><a href="tentangkami.html">Tentang Kami</a></li>
            <li><a href="kategori.html">Kategori</a></li>
            <li><a href="keranjang.html">Keranjang</a></li>
            <li class="akun-menu">
                <a href="akun.html">Akun</a>
                <ul class="dropdown">
                    <li><a href="login.html">Login</a></li>
                    <li><a href="register.html">Daftar</a></li>
                    <li><a href="profil.html">Profil Saya</a></li>
                    <li><a href="logout.php">Keluar</a></li>
                </ul>
            </li>
            <li><a href="kontak.html">Kontak Kami</a></li>
        </ul>
        <div class="search-bar">
            <input type="text" placeholder="Cari buah...">
        </div>
    </nav>

    <!-- Konten Akun -->
    <div class="content">
        <h2>Selamat datang, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
        <p>Ini adalah halaman akun pengguna. <?php echo htmlspecialchars($_SESSION['role']); ?></p>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</body>
</html>
