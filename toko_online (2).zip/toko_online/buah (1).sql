-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2024 at 07:45 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tokobuah`
--

-- --------------------------------------------------------

--
-- Table structure for table `buah`
--

CREATE TABLE `buah` (
  `id_buah` int(11) NOT NULL,
  `nama_buah` varchar(100) NOT NULL,
  `kategori_buah` varchar(100) NOT NULL,
  `harga` varchar(50) NOT NULL,
  `file_buah` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buah`
--

INSERT INTO `buah` (`id_buah`, `nama_buah`, `kategori_buah`, `harga`, `file_buah`) VALUES
(2, 'Mangga', 'Buah Tropis', 'Rp 15.000/kg', '2024-11-08 02.45.34.jpg'),
(3, 'Pepaya', 'Buah Tropis', 'Rp 12.000/kg', '2024-11-08 19.40.38.jpg'),
(4, 'Durian', 'Buah Tropis', 'Rp 50.000/kg', '2024-11-08 19.41.22.jpg'),
(5, 'Sirsak', 'Buah Tropis', 'Rp 18.000/kg', '2024-11-08 19.42.03.jpg'),
(6, 'Rambutan', 'Buah Tropis', 'Rp 13.000/kg', '2024-11-08 19.42.35.jpg'),
(7, 'Nangka', 'Buah Tropis', 'Rp 30.000/kg', '2024-11-08 19.43.20.jpg'),
(8, 'Salak', 'Buah Tropis', 'Rp 14.000/kg', '2024-11-08 19.45.06.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buah`
--
ALTER TABLE `buah`
  ADD PRIMARY KEY (`id_buah`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buah`
--
ALTER TABLE `buah`
  MODIFY `id_buah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
