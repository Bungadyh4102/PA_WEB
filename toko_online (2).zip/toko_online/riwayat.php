<?php
include "koneksi.php"; 

// Ambil data riwayat pembayaran
$sql = "SELECT * FROM riwayat_pembayaran"; // ganti dengan tabel yang sesuai di database Anda
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pembayaran</title>
    <style>
        /* Reset dasar */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f2f2f2;
            line-height: 1.6;
        }

        /* Navbar */
        .navbar {
            background-color: #4CAF50;
            padding: 15px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        .navbar .logo {
            font-size: 2em;
            font-weight: bold;
            letter-spacing: 1.5px;
        }

        .navbar .nav-links {
            display: flex;
            list-style: none;
        }

        .navbar .nav-links li {
            margin-left: 30px;
        }

        .navbar .nav-links a {
            color: white;
            text-decoration: none;
            font-size: 1.1em;
            transition: color 0.3s, transform 0.3s;
        }

        .navbar .nav-links a:hover {
            color: #ffd700;
            transform: scale(1.1);
        }

        .container {
            padding: 40px;
            margin: 30px auto;
            width: 90%;
            max-width: 1000px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table th, table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        table th {
            background-color: #4CAF50;
            color: white;
        }

        table td {
            background-color: #f9f9f9;
        }

        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        table tr:hover {
            background-color: #ddd;
        }

        .btn {
            display: inline-block;
            padding: 12px 24px;
            margin-top: 20px;
            background-color: #4CAF50;
            color: #fff;
            font-size: 18px;
            font-weight: 600;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s, box-shadow 0.3s;
        }

        .btn:hover {
            background-color: #388E3C;
        }
    </style>
</head>
<body>

    <!-- Navbar Admin -->
    <nav class="navbar">
        <div class="logo">Dashboard Admin</div>
        <ul class="nav-links">
            <li><a href="dashboard.php">Dashboard Admin</a></li>
            <li><a href="menuadmin.php">Data Buah</a></li>
            <li><a href="riwayat.php">Riwayat Pembayaran</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <h1>Riwayat Pembayaran</h1>

        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID Pembayaran</th>
                        <th>Nama Pembeli</th>
                        <th>Produk</th>
                        <th>Jumlah</th>
                        <th>Harga Total</th>
                        <th>Tanggal Pembayaran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id_pembayaran']; ?></td>
                            <td><?php echo $row['nama_pembeli']; ?></td>
                            <td><?php echo $row['produk']; ?></td>
                            <td><?php echo $row['jumlah']; ?></td>
                            <td><?php echo $row['harga_total']; ?></td> <!-- Menampilkan harga_total tanpa format -->
                            <td><?php echo $row['tanggal_pembayaran']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Belum ada riwayat pembayaran.</p>
        <?php endif; ?>

        <a href="dashboard.php" class="btn">Kembali ke Dashboard</a>
    </div>

    <?php $conn->close(); ?>
</body>
</html>
