-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2024 at 07:38 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tokobuah`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` enum('user','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'gibran', '321', 'user'),
(2, 'nur', '456456', 'user'),
(3, '342', '567567', 'user'),
(4, 'gibran', '234234', 'user'),
(5, 'bunga', '789789', 'user'),
(6, 'nelsi', '$2y$10$umvtefuKOI2HXz72JW6rYOnOr5B1Wv1vkI/MijCql0m', 'user'),
(7, 'ocha', '$2y$10$JlfgKT6DFPxEhJ1zXZrp..ioQcPXVVUpZmHAPr1ucDm', 'user'),
(8, 'Admin', '$2y$10$BNUXmaipzDYbJw4/N6DaXuNWyuP46Y1DUJVh0ZEL7rx', 'admin'),
(9, 'nelsi', '897897', 'user'),
(10, 'ADMIN', '456456', 'admin'),
(11, 'ADMIN', '123123', 'admin'),
(12, 'ocha', '234234', 'user'),
(13, 'ADMIN', '567567', 'admin'),
(14, 'Nazwa', '213213', 'user'),
(15, 'ADMIN', '234234', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
