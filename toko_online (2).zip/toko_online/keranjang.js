// keranjang.js

// Fungsi untuk menambah item ke keranjang
function tambahKeKeranjang(buah) {
    let keranjang = JSON.parse(localStorage.getItem("keranjang")) || [];
    keranjang.push(buah);
    localStorage.setItem("keranjang", JSON.stringify(keranjang));
    alert(buah.nama + " telah ditambahkan ke keranjang!");
}

// Fungsi untuk menampilkan item dalam keranjang
function tampilkanKeranjang() {
    let keranjang = JSON.parse(localStorage.getItem("keranjang")) || [];
    let keranjangHTML = "";

    keranjang.forEach((item) => {
        keranjangHTML += `<li>${item.nama} - Rp${item.harga}</li>`;
    });

    document.getElementById("keranjangList").innerHTML = keranjangHTML;
}
